export default function Hompage() {
  return <div>Hompage</div>;
}
